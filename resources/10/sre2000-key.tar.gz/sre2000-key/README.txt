
 This resource consists of metadata for the portion of the 2000 NIST Speaker
 Recognition Evaluation used in the callhome_diarization Kaldi recipe.
 The main file included here is the reference RTTM, which provides speaker
 labels for the recordings used in the evaluation.  This file was probably
 distributed as part of the 2000 NIST SRE, but does not appear to have been
 included in LDC's distribution of the dataset (LDC2001S97).  The segments
 and reco2num files are derived from the RTTM.

 File list
   README.txt      This file
   fullref.rttm    A Rich Transcription Time Marked (RTTM) that provides a
                   mapping from speech segments to speaker labels
   segments        Contiguous speech segments (ignores speaker changes)
   reco2num        The number of speakers per recording 
